# 使用Workbox取消PWA
該存儲庫是具有pwa支持的aframe應用程序的示例
使用工作箱庫。

-它包含內容緩存
-如果需要，它可以進行預緩存
-它支持manifest.json
-通過pwa的測試
