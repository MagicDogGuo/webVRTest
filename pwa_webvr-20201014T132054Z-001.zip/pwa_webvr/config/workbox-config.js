module.exports = {
  "globDirectory": "app",
  "globPatterns": [
    "**/*.{html,js}"
  ],
  "swDest": "app/sw-precaching.js",
  "swSrc": "app/sw.js"
};
